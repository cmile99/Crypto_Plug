package com.threeklines.cryptoplug;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.threeklines.cryptoplug.backside.ApiCenter;
import com.threeklines.cryptoplug.backside.DatabaseHandler;

public class MainActivity extends AppCompatActivity {
    private static final String TAG = "Main";
    private static final String DB_NAME = "my_db.db";
    public static final int DB_VERSION = 1;
    private ApiCenter apiCenter;
    private DatabaseHandler handler;
    private Button clickMe;
    private String key;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //instanciating variables
        apiCenter = new ApiCenter();
        handler = new DatabaseHandler(getApplicationContext(), DB_NAME, null, DB_VERSION);
        clickMe = findViewById(R.id.click_me);


        clickMe.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(), "Why did you click me!?", Toast.LENGTH_SHORT).show();
            }
        });

        apiCenter.getTwitterStatuses("#Bitcoin", handler);




    }
}